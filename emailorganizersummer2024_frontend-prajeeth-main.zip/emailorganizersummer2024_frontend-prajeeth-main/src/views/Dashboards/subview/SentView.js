import React from 'react'

export default function SentView() {
  return (
  <div>SentView</div>
  )
}
