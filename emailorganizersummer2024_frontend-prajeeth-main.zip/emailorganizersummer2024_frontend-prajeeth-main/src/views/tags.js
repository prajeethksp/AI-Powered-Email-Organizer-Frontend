import React, { Component } from 'react'

export default class Tags extends Component {
  render() {
    return (
      <div>tags</div>
    )
  }
}